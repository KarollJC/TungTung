CREATE DATABASE escuela;
USE escuela;

CREATE TABLE alumnos (
    clave INT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100)
);
